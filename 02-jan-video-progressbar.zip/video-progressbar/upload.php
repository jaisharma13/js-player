<?php

include 'config.php';
// print_r($db);die;



error_reporting(0);

$msg = "";

// If upload button is clicked ...
if (isset($_POST['submit'])) {

	$uploadfile = $_FILES["uploadfile"]["name"];
	$tempname = $_FILES["uploadfile"]["tmp_name"];

	$folder = "video/". $uploadfile;
    // print_r($folder);die;

    $sql = "INSERT INTO video (uploadfile) VALUES ('$uploadfile')";
	mysqli_query($db, $sql);

if (move_uploaded_file($tempname, $folder)) {
	echo "<h3> video uploaded successfully!</h3>";
    // header('location:http://localhost/video-progressbar/index-pop-up.php');


} 
else {
	echo "<h3> Failed to upload !</h3>";

    header('location: ');
}

}


exit();


?>